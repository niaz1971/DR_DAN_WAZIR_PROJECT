% Clear workspace and command window
clc;
clear;

% Sample data: Countries and their populations
countries = {'Australia', 'Canada', 'China', 'Croatia', 'Denmark', ...
             'France', 'Germany', 'Hong Kong', 'India', 'Japan', ...
             'Norway', 'Netherlands', 'Pakistan', 'Romania', ...
             'Spain', 'Switzerland', 'South Korea', 'Singapore', ...
             'Turkey', 'Taiwan', 'United Kingdom', 'United States'};
Journals = [3, 1, 4, 2, 1, 4, 4, 2, 9, 3, ...
               1, 3, 1, 1, 3, 5, 1, 1, 1, 1, ...
               25, 13];

% Define x and y coordinates for the bubble chart
x = 1:length(countries); % x-axis: index of countries
y = Journals;         % y-axis: population values

% Define bubble sizes based on populations (scale them for better visibility)
bubbleSizes = Journals * 10; % Scale up for better visibility

% Create a bubble chart
figure;
bubblechart(x, y, bubbleSizes);

% Customize the chart
xlabel('Countries');
ylabel('Journals');
title('Number of Journals Published by each Country on Textiles');

% Set x-tick labels to country names
xticks(x);
xticklabels(countries);
xtickangle(45); % Rotate x-axis labels for better visibility

% Add grid for better readability
grid on;

% Optional: Add data labels on top of bubbles
for i = 1:length(countries)
    text(x(i), y(i), num2str(Journals(i)), ...
         'HorizontalAlignment','center','VerticalAlignment','bottom');
end

% Adjust figure properties if needed
set(gcf,'Color','w'); % Set background color to white